import React from 'react'
import Nav from './Nav';
const About = () => {
  return (
    <div><Nav/>
    
    </div>
  )
}

export default About