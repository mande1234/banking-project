import React from 'react'
import { MidSection } from './MidsSection';
import Nav from './Nav';
const Home = () => {
  return (
    <div> 
    <Nav/>
    <MidSection/>
    </div>
  )
}

export default Home