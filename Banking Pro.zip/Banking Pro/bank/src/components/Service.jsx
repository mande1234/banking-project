import React from 'react'
import Nav from './Nav';
const Service = () => {
  return (
    <div><Nav/></div>
  )
}

export default Service