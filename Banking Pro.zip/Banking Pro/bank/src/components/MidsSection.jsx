import React from 'react'
import './midSection.css'




export const MidSection = () => {
  return (

    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
      </div>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="https://media.istockphoto.com/id/640267784/photo/bank-building.jpg?s=612x612&w=0&k=20&c=UTtm4t6WR-MLwO6ATq5l6n3SoCc6HpaClEFZMxO1Nek=" class="d-block w-100" alt="..." />
          <div class="carousel-caption d-none d-md-block">
            <h5>No.1 bank in asia</h5>
           
          </div>
        </div>
        <div class="carousel-item">
          <img src="https://www.shutterstock.com/image-photo/businessman-holding-word-banking-hand-260nw-1150180799.jpg " class="d-block w-100" alt="..." />
          <div class="carousel-caption d-none d-md-block">
          <h5>No.1 bank in asia</h5>
         
          </div>
        </div>
        <div class="carousel-item">
          <img src=" https://media.istockphoto.com/videos/bank-sign-on-modern-all-glass-building-in-business-district-with-video-id631545456?b=1&k=20&m=631545456&s=640x640&h=uDThSQ52TqYhfid2da0oOa1bIbkPYFcSrG-Ee5DK3Ps=" class="d-block w-100" alt="..." />
          <div class="carousel-caption d-none d-md-block">
          <h5>No.1 bank in asia</h5>
         
          </div>
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>

  )
}


